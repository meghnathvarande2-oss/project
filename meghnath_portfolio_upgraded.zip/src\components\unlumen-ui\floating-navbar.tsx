import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ChevronDown,
  Menu,
  X,
  FileText,
  FolderGit2,
  Sparkles,
  Cpu,
  BrainCircuit,
  Terminal,
  ExternalLink,
} from 'lucide-react';

export interface NavItem {
  name: string;
  link: string;
  dropdown?: Array<{
    title: string;
    description: string;
    link: string;
    icon?: React.ReactNode;
    badge?: string;
  }>;
}

export interface FloatingNavbarProps {
  navItems?: NavItem[];
  className?: string;
  onOpenResume?: () => void;
}

const defaultNavItems: NavItem[] = [
  { name: 'Home', link: '#home' },
  { name: 'About', link: '#about' },
  { name: 'Skills', link: '#skills' },
  {
    name: 'Projects',
    link: '#projects',
    dropdown: [
      {
        title: 'Student Performance Analyzer',
        description: 'Multi-dimensional NumPy statistical aggregation & grading engine',
        link: '#projects',
        badge: 'Featured AI',
        icon: <BrainCircuit className="w-4 h-4 text-orange-brand" />,
      },
      {
        title: 'ATM Banking System',
        description: 'Menu-driven simulation in C with state validation guards',
        link: '#projects',
        badge: 'Systems',
        icon: <Cpu className="w-4 h-4 text-purple-brand" />,
      },
      {
        title: 'Python Practice & Lab',
        description: 'Modular problem solving, Git history, & algorithmic exercises',
        link: '#projects',
        badge: 'Python',
        icon: <FolderGit2 className="w-4 h-4 text-orange-brand" />,
      },
      {
        title: 'Console Calculator',
        description: 'Arithmetic evaluation utility with defensive zero-division traps',
        link: '#projects',
        badge: 'C Logic',
        icon: <Terminal className="w-4 h-4 text-purple-brand" />,
      },
    ],
  },
  { name: 'Education', link: '#education' },
  { name: 'Contact', link: '#contact' },
];

export const FloatingNavbar: React.FC<FloatingNavbarProps> = ({
  navItems = defaultNavItems,
  className = '',
  onOpenResume,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);

      // Active section detection
      const sections = ['home', 'about', 'skills', 'projects', 'education', 'contact'];
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 140 && rect.bottom >= 140) {
            setActiveSection(id);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex justify-center px-4 pt-4 md:pt-6 pointer-events-none">
      <motion.nav
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className={`pointer-events-auto relative w-full max-w-5xl rounded-full transition-all duration-300 border ${
          scrolled
            ? 'bg-white/95 backdrop-blur-md shadow-elevated border-border py-2.5 px-4 md:px-6'
            : 'bg-white/90 backdrop-blur-sm shadow-soft border-border/80 py-3.5 px-5 md:px-7'
        } ${className}`}
      >
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            className="flex items-center gap-2 group cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-brand rounded-full"
            aria-label="Meghnath Varande Home"
          >
            <div className="w-9 h-9 rounded-full bg-purple-brand flex items-center justify-center text-white font-heading font-bold text-base shadow-sm group-hover:scale-105 transition-transform duration-200">
              M
            </div>
            <div className="flex flex-col text-left">
              <span className="font-heading font-bold text-base md:text-lg text-purple-brand leading-none">
                Meghnath
              </span>
              <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-orange-brand">
                AI / ML Student
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center gap-1 lg:gap-2">
            {navItems.map((item) => {
              const isActive = activeSection === item.link.replace('#', '');
              const hasDropdown = item.dropdown && item.dropdown.length > 0;

              return (
                <div
                  key={item.name}
                  className="relative"
                  onMouseEnter={() => hasDropdown && setActiveDropdown(item.name)}
                  onMouseLeave={() => hasDropdown && setActiveDropdown(null)}
                >
                  <a
                    href={item.link}
                    className={`flex items-center gap-1 px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? 'text-purple-brand bg-purple-subtle font-semibold'
                        : 'text-dark hover:text-purple-brand hover:bg-purple-brand/5'
                    }`}
                  >
                    {item.name}
                    {hasDropdown && (
                      <ChevronDown
                        className={`w-3.5 h-3.5 transition-transform duration-200 ${
                          activeDropdown === item.name ? 'rotate-180 text-orange-brand' : 'opacity-60'
                        }`}
                      />
                    )}
                  </a>

                  {/* Dropdown Panel */}
                  <AnimatePresence>
                    {hasDropdown && activeDropdown === item.name && (
                      <motion.div
                        initial={{ opacity: 0, y: 10, scale: 0.96 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.96 }}
                        transition={{ duration: 0.18, ease: 'easeOut' }}
                        className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-80 p-2.5 rounded-2xl bg-white/98 backdrop-blur-xl border border-border shadow-elevated z-50"
                      >
                        <div className="text-[11px] font-mono uppercase tracking-wider text-dark-muted px-3 py-1 font-semibold">
                          Portfolio Work
                        </div>
                        <div className="space-y-1">
                          {item.dropdown?.map((sub) => (
                            <a
                              key={sub.title}
                              href={sub.link}
                              onClick={() => setActiveDropdown(null)}
                              className="group flex items-start gap-3 p-2.5 rounded-xl hover:bg-bg-alt transition-colors"
                            >
                              <div className="mt-0.5 p-1.5 rounded-lg bg-white border border-border shadow-2xs group-hover:border-orange-brand/50 transition-colors">
                                {sub.icon}
                              </div>
                              <div className="flex-1 text-left">
                                <div className="flex items-center justify-between">
                                  <span className="text-xs font-semibold text-purple-brand group-hover:text-orange-brand transition-colors">
                                    {sub.title}
                                  </span>
                                  {sub.badge && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-orange-light text-orange-brand font-mono font-medium">
                                      {sub.badge}
                                    </span>
                                  )}
                                </div>
                                <p className="text-[11px] text-dark-muted line-clamp-1 mt-0.5">
                                  {sub.description}
                                </p>
                              </div>
                            </a>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>

          {/* Action Buttons: Resume + CTA */}
          <div className="flex items-center gap-2">
            {onOpenResume && (
              <button
                onClick={onOpenResume}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-border text-xs font-medium text-dark hover:border-purple-brand hover:text-purple-brand hover:bg-purple-subtle transition-all duration-200"
                aria-label="View Resume"
              >
                <FileText className="w-3.5 h-3.5 text-purple-brand" />
                <span>Resume</span>
              </button>
            )}

            {/* Dynamic Expanding CTA Button */}
            <a
              href="#projects"
              className="inline-flex items-center gap-1.5 px-4 py-1.5 md:py-2 rounded-full bg-orange-brand hover:bg-orange-hover text-white text-xs md:text-sm font-semibold shadow-orange-glow transition-all duration-200 hover:scale-[1.03] active:scale-95"
            >
              <span>View Projects</span>
              <Sparkles className="w-3.5 h-3.5" />
            </a>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-full text-dark hover:text-purple-brand hover:bg-purple-subtle transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-purple-brand"
              aria-label="Toggle navigation menu"
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="w-5 h-5 text-orange-brand" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.25, ease: 'easeInOut' }}
              className="md:hidden overflow-hidden pt-4 pb-2 border-t border-border mt-3 text-left"
            >
              <div className="flex flex-col gap-1.5">
                {navItems.map((item) => (
                  <div key={item.name}>
                    <a
                      href={item.link}
                      onClick={() => setMobileMenuOpen(false)}
                      className={`block px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
                        activeSection === item.link.replace('#', '')
                          ? 'text-purple-brand bg-purple-subtle font-semibold'
                          : 'text-dark hover:text-purple-brand hover:bg-bg-alt'
                      }`}
                    >
                      {item.name}
                    </a>
                  </div>
                ))}

                {onOpenResume && (
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenResume();
                    }}
                    className="flex items-center gap-2 px-4 py-2 mt-2 rounded-xl text-sm font-medium text-purple-brand bg-purple-subtle"
                  >
                    <FileText className="w-4 h-4" />
                    <span>View Meghnath's Resume</span>
                  </button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>
    </header>
  );
};

export default FloatingNavbar;
