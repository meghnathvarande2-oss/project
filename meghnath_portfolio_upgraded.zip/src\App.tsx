import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Brain,
  Code2,
  Terminal,
  Database,
  Sparkles,
  GitBranch,
  Github,
  Linkedin,
  Mail,
  FileText,
  CheckCircle2,
  Trophy,
  GraduationCap,
  Award,
  Layers,
  ArrowRight,
  ExternalLink,
  Play,
  RotateCcw,
  Printer,
  X,
  Send,
  MapPin,
  Calendar,
  Building2,
  Globe,
  Briefcase,
} from 'lucide-react';

import { FloatingNavbar } from '@/components/unlumen-ui/floating-navbar';
import { SmartAnimateText } from '@/components/unlumen-ui/smart-animate-text';
import { HoverImageList, HoverImageListItem } from '@/components/unlumen-ui/hover-image-list';
import { DiaTextReveal } from '@/components/unlumen-ui/dia-text-reveal';
import { FloatingTooltip } from '@/components/unlumen-ui/floating-tooltip';

export default function App() {
  const [resumeModalOpen, setResumeModalOpen] = useState(false);
  const [activeTopic, setActiveTopic] = useState('Internship Opportunity');

  // Interactive NumPy Playground State
  const [marksInput, setMarksInput] = useState('88, 94, 76, 92, 85');
  const [calcStats, setCalcStats] = useState({
    total: 435,
    average: 87.0,
    min: 76,
    max: 94,
    stdDev: 6.48,
    grade: 'A (Distinction)',
    count: 5,
  });

  // Calculate NumPy-like statistics
  const handleCalculate = (rawInput?: string) => {
    const input = rawInput !== undefined ? rawInput : marksInput;
    const values = input
      .split(',')
      .map((v) => parseFloat(v.trim()))
      .filter((v) => !isNaN(v) && v >= 0 && v <= 100);

    if (values.length === 0) return;

    const count = values.length;
    const total = values.reduce((sum, n) => sum + n, 0);
    const average = total / count;
    const min = Math.min(...values);
    const max = Math.max(...values);
    const variance =
      values.reduce((sum, n) => sum + Math.pow(n - average, 2), 0) / count;
    const stdDev = Math.sqrt(variance);

    let grade = 'F';
    if (average >= 85) grade = 'A+ (Exemplary)';
    else if (average >= 75) grade = 'A (Distinction)';
    else if (average >= 60) grade = 'B (First Class)';
    else if (average >= 50) grade = 'C (Second Class)';
    else if (average >= 40) grade = 'D (Pass)';

    setCalcStats({
      total: Math.round(total * 100) / 100,
      average: Math.round(average * 10) / 10,
      min,
      max,
      stdDev: Math.round(stdDev * 100) / 100,
      grade,
      count,
    });
  };

  // Projects data for HoverImageList
  const projectsData: HoverImageListItem[] = [
    {
      id: 'student-performance-analyzer',
      title: 'Student Performance Analyzer',
      subtitle: 'Data Processing with NumPy',
      category: 'AI & Data Science',
      description:
        'A Python program that structures student marks into multi-dimensional NumPy arrays for statistical aggregation—computing class averages, standard distributions, min/max metrics, and automated grade boundaries.',
      tags: ['Python', 'NumPy', 'Data Analysis', 'Vectorization'],
      image: '/assets/img/project-numpy.svg',
      githubUrl: 'https://github.com/meghnathvarande2-oss',
      demoUrl: '#playground',
    },
    {
      id: 'atm-management-system',
      title: 'ATM Management System',
      subtitle: 'Menu-Driven Banking Simulation in C',
      category: 'Systems Logic',
      description:
        'A console-based banking utility written in C implementing secure PIN authentication, account balance audits, deposit handling, and defensive withdrawal validations with insufficient-fund protection.',
      tags: ['C Language', 'State Logic', 'CLI', 'Defensive Guard'],
      image: '/assets/img/project-atm.svg',
      githubUrl: 'https://github.com/meghnathvarande2-oss',
    },
    {
      id: 'console-calculator-engine',
      title: 'Console Calculator Engine',
      subtitle: 'Defensive Arithmetic in C',
      category: 'Systems Logic',
      description:
        'An arithmetic evaluation terminal utility featuring modular math operations (+, -, *, /, %). Designed with defensive programming techniques, including zero-division exception handling and buffer clearing.',
      tags: ['C Language', 'Defensive Code', 'Arithmetic'],
      image: '/assets/img/project-calc.svg',
      githubUrl: 'https://github.com/meghnathvarande2-oss',
    },
    {
      id: 'python-practice-repo',
      title: 'Python Practice & Lab Repository',
      subtitle: 'Core Logic & Version Control',
      category: 'Programming',
      description:
        'A structured public repository tracking incremental problem solving in Python. Contains syntax exercises, control flow branching, functional decomposition, file handling, and modular scripts with Git history.',
      tags: ['Python 3', 'Git Flow', 'Algorithms', 'Clean Code'],
      image: '/assets/img/project-python.svg',
      githubUrl: 'https://github.com/meghnathvarande2-oss',
    },
  ];

  // Technical Skills formatted strictly to prompt specification
  const skillsCategories = [
    {
      category: 'Programming',
      icon: <Code2 className="w-5 h-5 text-purple-brand" />,
      skills: [
        { name: 'Python', level: 'Beginner to Intermediate', highlight: true },
        { name: 'C', level: 'Intermediate', highlight: false },
        { name: 'C++', level: 'Intermediate', highlight: false },
        { name: 'Java', level: 'Intermediate', highlight: false },
      ],
    },
    {
      category: 'Data Science',
      icon: <Database className="w-5 h-5 text-orange-brand" />,
      skills: [
        { name: 'NumPy', level: 'Intermediate', highlight: true },
        { name: 'Pandas', level: 'Beginner', highlight: false },
      ],
    },
    {
      category: 'AI & Machine Learning',
      icon: <Brain className="w-5 h-5 text-purple-brand" />,
      skills: [
        { name: 'Machine Learning Fundamentals', level: 'Beginner', highlight: false },
        { name: 'Generative AI Fundamentals', level: 'Beginner', highlight: true },
      ],
    },
    {
      category: 'Web Development',
      icon: <Globe className="w-5 h-5 text-orange-brand" />,
      skills: [
        { name: 'HTML', level: 'Intermediate', highlight: false },
        { name: 'CSS', level: 'Beginner', highlight: false },
        { name: 'JavaScript', level: 'Beginner', highlight: false },
      ],
    },
    {
      category: 'Developer Tools',
      icon: <GitBranch className="w-5 h-5 text-purple-brand" />,
      skills: [
        { name: 'Git', level: 'Daily Use', highlight: true },
        { name: 'GitHub', level: 'Daily Use', highlight: true },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white text-dark flex flex-col font-sans selection:bg-orange-light selection:text-orange-brand">
      {/* 1. Motion Navigation Menu */}
      <FloatingNavbar onOpenResume={() => setResumeModalOpen(true)} />

      <main className="flex-1">
        {/* ==================== HERO SECTION ==================== */}
        <section
          id="home"
          className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-white"
        >
          {/* Subtle Ambient Background Gradients (60% White dominant) */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-purple-subtle rounded-full blur-3xl pointer-events-none" />
          <div className="absolute top-20 right-10 w-72 h-72 bg-orange-subtle rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              {/* Left Column: Hero Copy */}
              <div className="lg:col-span-7 text-left space-y-6">
                {/* Available for Internship Badge */}
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-bg-alt border border-border shadow-2xs">
                  <span className="w-2.5 h-2.5 rounded-full bg-orange-brand animate-pulse" />
                  <span className="text-xs font-mono font-semibold text-purple-brand">
                    Available for AI / ML Internships
                  </span>
                </div>

                {/* 1. Dia Text Reveal for Main Headline */}
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-purple-brand tracking-tight leading-[1.15]">
                  Hi, I'm <br />
                  <DiaTextReveal
                    text="Meghnath Varande"
                    className="text-4xl sm:text-5xl lg:text-6xl font-heading font-extrabold"
                  />
                </h1>

                {/* 4. Smart Animated Text for Rotating Hero Action Words */}
                <div className="flex flex-wrap items-center gap-2 text-xl sm:text-2xl font-heading font-semibold text-dark-muted">
                  <span>Specializing in</span>
                  <SmartAnimateText
                    value="Building."
                    words={['Building.', 'Learning.', 'Developing.', 'Innovating.']}
                    interval={2800}
                    className="text-xl sm:text-2xl font-bold"
                  />
                  <span>intelligent data solutions.</span>
                </div>

                {/* Hero Description */}
                <p className="text-base sm:text-lg text-dark-muted leading-relaxed max-w-xl">
                  2nd-year AI &amp; Machine Learning diploma student (MSBTE) with{' '}
                  <strong className="text-purple-brand font-semibold">93% SSC merit</strong>.
                  Building practical foundations in Python, NumPy, Pandas, and GenAI to solve
                  real-world problems through data and automation.
                </p>

                {/* Hero CTA Action Buttons */}
                <div className="flex flex-wrap items-center gap-3 pt-2">
                  <a
                    href="#projects"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-orange-brand hover:bg-orange-hover text-white font-semibold text-sm shadow-orange-glow transition-all duration-200 hover:scale-[1.03] active:scale-95"
                  >
                    <span>Explore Projects</span>
                    <ArrowRight className="w-4 h-4" />
                  </a>

                  <button
                    onClick={() => setResumeModalOpen(true)}
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-full border border-purple-brand text-purple-brand hover:bg-purple-subtle font-semibold text-sm transition-all duration-200"
                  >
                    <FileText className="w-4 h-4" />
                    <span>View Resume</span>
                  </button>

                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 px-5 py-3 rounded-full text-dark hover:text-purple-brand font-medium text-sm transition-colors"
                  >
                    <span>Contact Me</span>
                  </a>
                </div>

                {/* Social Bar with Floating Tooltips */}
                <div className="flex items-center gap-4 pt-4 border-t border-border">
                  <span className="text-xs font-mono text-dark-muted uppercase tracking-wider font-semibold">
                    Connect:
                  </span>
                  <div className="flex items-center gap-2">
                    {/* 3. Floating Tooltip Examples */}
                    <FloatingTooltip content="GitHub Profile">
                      <a
                        href="https://github.com/meghnathvarande2-oss"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2.5 rounded-full border border-border text-dark hover:text-purple-brand hover:border-purple-brand hover:bg-purple-subtle transition-all"
                        aria-label="GitHub Profile"
                      >
                        <Github className="w-4 h-4" />
                      </a>
                    </FloatingTooltip>

                    <FloatingTooltip content="LinkedIn Profile">
                      <a
                        href="https://www.linkedin.com/in/meghnath-varande-10823b438"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2.5 rounded-full border border-border text-dark hover:text-purple-brand hover:border-purple-brand hover:bg-purple-subtle transition-all"
                        aria-label="LinkedIn Profile"
                      >
                        <Linkedin className="w-4 h-4" />
                      </a>
                    </FloatingTooltip>

                    <FloatingTooltip content="Send Email">
                      <a
                        href="mailto:meghnathvarande2@gmail.com"
                        className="p-2.5 rounded-full border border-border text-dark hover:text-orange-brand hover:border-orange-brand hover:bg-orange-light transition-all"
                        aria-label="Email Address"
                      >
                        <Mail className="w-4 h-4" />
                      </a>
                    </FloatingTooltip>
                  </div>
                </div>
              </div>

              {/* Right Column: Hero Profile Card */}
              <div className="lg:col-span-5 flex justify-center">
                <div className="relative w-full max-w-sm">
                  {/* Outer Purple Accent Glow */}
                  <div className="absolute inset-0 bg-gradient-to-tr from-purple-brand to-orange-brand rounded-3xl blur-xl opacity-20 transform -rotate-3 scale-105" />

                  {/* Main Avatar Card */}
                  <div className="relative bg-white rounded-3xl p-6 border border-border shadow-elevated text-center">
                    {/* Profile Monogram Avatar */}
                    <div className="w-28 h-28 mx-auto rounded-2xl bg-purple-brand text-white flex items-center justify-center font-heading font-extrabold text-4xl shadow-purple-glow border-4 border-white mb-4">
                      MV
                    </div>

                    <h3 className="font-heading font-bold text-xl text-purple-brand">
                      Meghnath Varande
                    </h3>
                    <p className="text-xs font-mono text-orange-brand font-semibold mt-0.5">
                      Diploma in AI &amp; Machine Learning
                    </p>
                    <p className="text-xs text-dark-muted mt-2">
                      Adarsh Institute of Tech, Vita (MSBTE)
                    </p>

                    {/* Quick Badges */}
                    <div className="grid grid-cols-2 gap-2 mt-5 text-left">
                      <FloatingTooltip content="SSC Board Merit">
                        <div className="p-2.5 rounded-xl bg-bg-alt border border-border">
                          <span className="text-[10px] font-mono text-dark-muted block">
                            SSC Merit
                          </span>
                          <span className="text-sm font-bold text-purple-brand font-heading">
                            93% Distinction
                          </span>
                        </div>
                      </FloatingTooltip>

                      <FloatingTooltip content="Focus Ecosystem">
                        <div className="p-2.5 rounded-xl bg-bg-alt border border-border">
                          <span className="text-[10px] font-mono text-dark-muted block">
                            Core Focus
                          </span>
                          <span className="text-sm font-bold text-orange-brand font-heading">
                            Python &amp; NumPy
                          </span>
                        </div>
                      </FloatingTooltip>
                    </div>

                    <div className="mt-4 pt-3 border-t border-border flex items-center justify-between text-xs font-mono text-dark-muted">
                      <span className="flex items-center gap-1.5">
                        <MapPin className="w-3.5 h-3.5 text-purple-brand" /> Patan, MH, India
                      </span>
                      <span className="flex items-center gap-1.5 text-orange-brand font-semibold">
                        <Calendar className="w-3.5 h-3.5" /> Class of '28
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== STATS HIGHLIGHTS BAR ==================== */}
        <section className="py-8 bg-bg-alt border-y border-border">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div className="p-4 rounded-2xl bg-white border border-border shadow-2xs">
                <div className="text-3xl font-heading font-extrabold text-purple-brand">
                  93%
                </div>
                <div className="text-xs font-medium text-dark-muted mt-1">
                  SSC Board Merit
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-border shadow-2xs">
                <div className="text-3xl font-heading font-extrabold text-orange-brand">
                  4+
                </div>
                <div className="text-xs font-medium text-dark-muted mt-1">
                  Hands-on Projects
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-border shadow-2xs">
                <div className="text-3xl font-heading font-extrabold text-purple-brand">
                  7+
                </div>
                <div className="text-xs font-medium text-dark-muted mt-1">
                  Verified Certifications
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-border shadow-2xs">
                <div className="text-3xl font-heading font-extrabold text-orange-brand">
                  2028
                </div>
                <div className="text-xs font-medium text-dark-muted mt-1">
                  Expected Diploma Batch
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== ABOUT SECTION ==================== */}
        <section id="about" className="py-20 md:py-28 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-purple-subtle text-purple-brand">
                Profile &amp; Background
              </span>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-purple-brand mt-3">
                <DiaTextReveal text="About Meghnath Varande" />
              </h2>
              <p className="text-sm md:text-base text-dark-muted mt-3">
                Dedicated to building a strong foundation in programming, data, and intelligent systems.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
              <div className="lg:col-span-7 space-y-4 text-left">
                <h3 className="text-xl sm:text-2xl font-heading font-bold text-purple-brand">
                  Turning curiosity into real code &amp; data solutions
                </h3>
                <p className="text-sm sm:text-base text-dark leading-relaxed">
                  I am currently in my 2nd year of the Diploma in Artificial Intelligence and Machine
                  Learning at Adarsh Institute of Technology, Vita (affiliated with MSBTE). With an
                  academic foundation marked by 93% in SSC, I bring discipline, dedication, and
                  analytical curiosity to software development.
                </p>
                <p className="text-sm sm:text-base text-dark-muted leading-relaxed">
                  Having grounded my fundamentals in core programming languages like C, C++, and Java,
                  my focus is centered on the Python data science ecosystem—leveraging NumPy for
                  vectorized computations, exploring Pandas for data manipulation, and mastering
                  Generative AI and prompt engineering concepts.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4">
                  <div className="flex items-start gap-3 p-3.5 rounded-xl bg-bg-alt border border-border">
                    <CheckCircle2 className="w-5 h-5 text-orange-brand shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-purple-brand">Project-Driven</h4>
                      <p className="text-[11px] text-dark-muted mt-0.5">
                        Translating theoretical math &amp; logic into working repositories.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3.5 rounded-xl bg-bg-alt border border-border">
                    <GitBranch className="w-5 h-5 text-purple-brand shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-purple-brand">Clean Git Habits</h4>
                      <p className="text-[11px] text-dark-muted mt-0.5">
                        Disciplined commit history, modular files, and GitHub daily usage.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Key Facts List */}
              <div className="lg:col-span-5 space-y-3">
                <div className="p-4 rounded-2xl bg-bg-alt border border-border text-left">
                  <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                    Institution
                  </span>
                  <div className="text-sm font-semibold text-purple-brand mt-0.5">
                    Adarsh Institute of Technology, Vita
                  </div>
                  <div className="text-xs text-dark-muted">MSBTE Board &bull; AI/ML Branch</div>
                </div>

                <div className="p-4 rounded-2xl bg-bg-alt border border-border text-left">
                  <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                    Academic Record
                  </span>
                  <div className="text-sm font-semibold text-purple-brand mt-0.5">
                    93% Secondary School Certificate (SSC)
                  </div>
                  <div className="text-xs text-dark-muted">Distinction in Math &amp; Science</div>
                </div>

                <div className="p-4 rounded-2xl bg-bg-alt border border-border text-left">
                  <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                    Current Focus
                  </span>
                  <div className="text-sm font-semibold text-orange-brand mt-0.5">
                    Python, NumPy, Pandas &amp; AI Automation
                  </div>
                  <div className="text-xs text-dark-muted">Seeking Industry Internship</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== TECHNICAL SKILLS & LEVELS ==================== */}
        {/* Strictly compliant with prompt specification: No invented percentages! */}
        <section id="skills" className="py-20 md:py-28 bg-bg-alt border-y border-border">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-purple-subtle text-purple-brand">
                Verified Technical Proficiencies
              </span>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-purple-brand mt-3">
                <DiaTextReveal text="Skills &amp; Technologies" />
              </h2>
              <p className="text-sm md:text-base text-dark-muted mt-3">
                Displaying exact skill competencies and practical levels across programming, data science, AI, web, and developer tools.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillsCategories.map((cat) => (
                <div
                  key={cat.category}
                  className="bg-white rounded-2xl p-6 border border-border shadow-soft hover:shadow-elevated transition-shadow duration-200 text-left flex flex-col justify-between"
                >
                  <div>
                    {/* Category Header */}
                    <div className="flex items-center gap-3 pb-4 mb-4 border-b border-border">
                      <div className="p-2 rounded-xl bg-bg-alt border border-border">
                        {cat.icon}
                      </div>
                      <h3 className="font-heading font-bold text-base text-purple-brand">
                        {cat.category}
                      </h3>
                    </div>

                    {/* Skill Items */}
                    <div className="space-y-3">
                      {cat.skills.map((skill) => (
                        <FloatingTooltip
                          key={skill.name}
                          content={`${skill.name}: ${skill.level}`}
                          className="w-full"
                        >
                          <div
                            className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all duration-150 ${
                              skill.highlight
                                ? 'bg-orange-light/30 border-orange-brand/30 hover:border-orange-brand'
                                : 'bg-bg-alt border-border hover:border-purple-brand/40'
                            }`}
                          >
                            <span className="text-sm font-semibold text-dark">
                              {skill.name}
                            </span>
                            <span
                              className={`text-[11px] font-mono px-2.5 py-0.5 rounded-full font-medium ${
                                skill.level === 'Daily Use'
                                  ? 'bg-purple-brand text-white'
                                  : skill.level === 'Intermediate'
                                  ? 'bg-purple-subtle text-purple-brand'
                                  : skill.level === 'Beginner to Intermediate'
                                  ? 'bg-orange-brand text-white shadow-2xs'
                                  : 'bg-white text-dark-muted border border-border'
                              }`}
                            >
                              {skill.level}
                            </span>
                          </div>
                        </FloatingTooltip>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ==================== 5. HOVER IMAGE LIST PROJECTS ==================== */}
        <section id="projects" className="py-20 md:py-28 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-orange-light text-orange-brand">
                Featured Repositories
              </span>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-purple-brand mt-3">
                <DiaTextReveal text="Interactive Project Showcase" />
              </h2>
              <p className="text-sm md:text-base text-dark-muted mt-3">
                Hover over any project below to activate the dynamic spring preview panel.
              </p>
            </div>

            {/* HoverImageList Component */}
            <HoverImageList items={projectsData} />

            {/* ==================== INTERACTIVE NUMPY PLAYGROUND ==================== */}
            <div
              id="playground"
              className="mt-20 p-6 sm:p-8 rounded-3xl bg-bg-alt border border-border shadow-soft text-left"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white border border-border text-xs font-mono text-orange-brand font-semibold mb-2">
                    <Sparkles className="w-3.5 h-3.5" /> Live NumPy Logic Simulator
                  </div>
                  <h3 className="text-xl sm:text-2xl font-heading font-bold text-purple-brand">
                    Test My NumPy Algorithm: Student Performance Analyzer
                  </h3>
                  <p className="text-xs sm:text-sm text-dark-muted mt-1">
                    Enter comma-separated marks (0-100) or choose a preset to compute statistical distributions in real time.
                  </p>
                </div>

                {/* Preset Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => {
                      setMarksInput('88, 94, 76, 92, 85');
                      handleCalculate('88, 94, 76, 92, 85');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-white border border-border text-xs font-medium text-purple-brand hover:border-purple-brand transition-colors"
                  >
                    Preset 1 (Merit)
                  </button>
                  <button
                    onClick={() => {
                      setMarksInput('62, 74, 58, 81, 69, 77');
                      handleCalculate('62, 74, 58, 81, 69, 77');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-white border border-border text-xs font-medium text-purple-brand hover:border-purple-brand transition-colors"
                  >
                    Preset 2 (Spread)
                  </button>
                </div>
              </div>

              {/* Controls */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mt-6 items-center">
                <div className="md:col-span-8">
                  <label className="block text-xs font-mono text-dark-muted font-semibold mb-1">
                    Student Marks Array:
                  </label>
                  <input
                    type="text"
                    value={marksInput}
                    onChange={(e) => setMarksInput(e.target.value)}
                    placeholder="e.g. 78, 85, 92, 64, 89"
                    className="w-full px-4 py-2.5 rounded-xl border border-border bg-white text-dark font-mono text-sm focus:outline-none focus:ring-2 focus:ring-orange-brand"
                  />
                </div>
                <div className="md:col-span-4 flex items-end">
                  <button
                    onClick={() => handleCalculate()}
                    className="w-full flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-orange-brand hover:bg-orange-hover text-white font-semibold text-sm shadow-orange-glow transition-all"
                  >
                    <Play className="w-4 h-4" />
                    <span>Run NumPy Analysis</span>
                  </button>
                </div>
              </div>

              {/* Real-time Results Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mt-6">
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Count (N)</span>
                  <span className="text-lg font-bold text-purple-brand font-mono">{calcStats.count}</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Mean / Avg</span>
                  <span className="text-lg font-bold text-orange-brand font-mono">{calcStats.average}%</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Min Mark</span>
                  <span className="text-lg font-bold text-purple-brand font-mono">{calcStats.min}</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Max Mark</span>
                  <span className="text-lg font-bold text-purple-brand font-mono">{calcStats.max}</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Std Deviation</span>
                  <span className="text-lg font-bold text-dark font-mono">&plusmn;{calcStats.stdDev}</span>
                </div>
                <div className="p-3 rounded-xl bg-white border border-border text-center">
                  <span className="text-[10px] font-mono text-dark-muted uppercase block">Bracket</span>
                  <span className="text-xs font-bold text-orange-brand font-mono truncate block">
                    {calcStats.grade}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== EDUCATION & CERTIFICATIONS ==================== */}
        <section id="education" className="py-20 md:py-28 bg-bg-alt border-y border-border">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-purple-subtle text-purple-brand">
                Academic Qualifications
              </span>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-purple-brand mt-3">
                <DiaTextReveal text="Education &amp; Credentials" />
              </h2>
              <p className="text-sm md:text-base text-dark-muted mt-3">
                Formal diploma education under MSBTE alongside verified certifications from global tech leaders.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 text-left">
              {/* Education Timeline */}
              <div className="space-y-4">
                <h3 className="font-heading font-bold text-lg text-purple-brand flex items-center gap-2">
                  <GraduationCap className="w-5 h-5 text-orange-brand" /> Academic Degrees
                </h3>

                <div className="p-6 rounded-2xl bg-white border border-border shadow-soft relative overflow-hidden">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono font-semibold text-orange-brand uppercase">
                      2024 &ndash; 2028 (Expected)
                    </span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-subtle text-purple-brand font-semibold">
                      In Progress (2nd Year)
                    </span>
                  </div>
                  <h4 className="font-heading font-bold text-lg text-purple-brand mt-2">
                    Diploma in Artificial Intelligence &amp; Machine Learning
                  </h4>
                  <p className="text-sm font-medium text-dark mt-0.5">
                    Adarsh Institute of Technology, Vita &bull; MSBTE Affiliated
                  </p>
                  <p className="text-xs text-dark-muted mt-2 leading-relaxed">
                    Coursework covers C, C++, Java, Python, Data Structures, Relational Databases, and Machine Learning foundations.
                  </p>
                </div>

                <div className="p-6 rounded-2xl bg-white border border-border shadow-soft">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono font-semibold text-orange-brand uppercase">
                      Completed Feb 2025
                    </span>
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-orange-light text-orange-brand font-semibold">
                      93% Distinction
                    </span>
                  </div>
                  <h4 className="font-heading font-bold text-lg text-purple-brand mt-2">
                    Secondary School Certificate (SSC)
                  </h4>
                  <p className="text-sm font-medium text-dark mt-0.5">
                    Maharashtra State Board (MSBSHSE)
                  </p>
                  <p className="text-xs text-dark-muted mt-2 leading-relaxed">
                    Graduated with highest merit with distinction marks across Mathematics and Physical Science disciplines.
                  </p>
                </div>
              </div>

              {/* Verified Certifications */}
              <div className="space-y-4">
                <h3 className="font-heading font-bold text-lg text-purple-brand flex items-center gap-2">
                  <Award className="w-5 h-5 text-purple-brand" /> Verified Certifications
                </h3>

                <div className="space-y-2.5">
                  {[
                    { title: 'Foundation in Generative AI', issuer: 'IBM', date: '2024' },
                    { title: 'Use AI for Everyday Tasks', issuer: 'Microsoft', date: '2024' },
                    { title: 'Microsoft 365 Copilot Chat (Basic)', issuer: 'Microsoft', date: '2024' },
                    { title: 'Yuva AI for All', issuer: 'Coursera / Yuva', date: '2024' },
                    { title: 'Communication & Interview Skills', issuer: 'TCS iON', date: '2024' },
                    { title: 'Effective Presentations', issuer: 'HP LIFE', date: '2024' },
                  ].map((cert) => (
                    <div
                      key={cert.title}
                      className="p-3.5 rounded-xl bg-white border border-border flex items-center justify-between hover:border-orange-brand/40 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <CheckCircle2 className="w-4 h-4 text-orange-brand shrink-0" />
                        <div>
                          <h5 className="text-xs font-semibold text-purple-brand">{cert.title}</h5>
                          <span className="text-[11px] text-dark-muted font-mono">{cert.issuer}</span>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-bg-alt text-dark-muted border border-border">
                        Verified
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ==================== CONTACT SECTION ==================== */}
        <section id="contact" className="py-20 md:py-28 bg-white">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-orange-light text-orange-brand">
                Connect Directly
              </span>
              <h2 className="text-3xl sm:text-4xl font-heading font-bold text-purple-brand mt-3">
                <DiaTextReveal text="Get in Touch" />
              </h2>
              <p className="text-sm md:text-base text-dark-muted mt-3">
                Interested in offering an internship, collaborating on a project, or discussing AI? Let's connect.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
              {/* Left Column: Direct Details */}
              <div className="lg:col-span-5 space-y-4 text-left">
                <div className="p-5 rounded-2xl bg-bg-alt border border-border">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-white text-purple-brand border border-border">
                      <Mail className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                        Email Address
                      </span>
                      <a
                        href="mailto:meghnathvarande2@gmail.com"
                        className="text-sm font-semibold text-purple-brand hover:text-orange-brand block transition-colors"
                      >
                        meghnathvarande2@gmail.com
                      </a>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-bg-alt border border-border">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-white text-orange-brand border border-border">
                      <Linkedin className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                        LinkedIn Network
                      </span>
                      <a
                        href="https://www.linkedin.com/in/meghnath-varande-10823b438"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm font-semibold text-purple-brand hover:text-orange-brand block transition-colors"
                      >
                        meghnath-varande &bull; Connect <ExternalLink className="w-3 h-3 inline ml-1" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-bg-alt border border-border">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-white text-purple-brand border border-border">
                      <Github className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono text-dark-muted uppercase font-bold">
                        GitHub Profile
                      </span>
                      <a
                        href="https://github.com/meghnathvarande2-oss"
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm font-semibold text-purple-brand hover:text-orange-brand block transition-colors"
                      >
                        meghnathvarande2-oss <ExternalLink className="w-3 h-3 inline ml-1" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="p-5 rounded-2xl bg-purple-brand text-white">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-orange-brand animate-ping" />
                    <span className="font-heading font-bold text-sm">Open for Internship Offers</span>
                  </div>
                  <p className="text-xs text-white/80 leading-relaxed">
                    Available for remote AI/ML engineering internships or on-site roles in Maharashtra. Eager to contribute to production codebases and data pipelines.
                  </p>
                </div>
              </div>

              {/* Right Column: Contact Form */}
              <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl bg-bg-alt border border-border shadow-soft text-left">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const name = (form.elements.namedItem('name') as HTMLInputElement).value;
                    const email = (form.elements.namedItem('email') as HTMLInputElement).value;
                    const message = (form.elements.namedItem('message') as HTMLTextAreaElement).value;
                    const subject = `[${activeTopic}] Inquiry from ${name}`;
                    const body = `Name: ${name}\nEmail: ${email}\nTopic: ${activeTopic}\n\nMessage:\n${message}`;
                    window.location.href = `mailto:meghnathvarande2@gmail.com?subject=${encodeURIComponent(
                      subject
                    )}&body=${encodeURIComponent(body)}`;
                  }}
                  className="space-y-4"
                >
                  <h4 className="font-heading font-bold text-lg text-purple-brand mb-1">
                    Send a Direct Message
                  </h4>

                  {/* Topic Selectors */}
                  <div>
                    <label className="block text-xs font-mono text-dark-muted font-semibold mb-2">
                      Choose Topic:
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {[
                        'Internship Opportunity',
                        'Project Collaboration',
                        'Mentorship',
                        'General Inquiry',
                      ].map((topic) => (
                        <button
                          key={topic}
                          type="button"
                          onClick={() => setActiveTopic(topic)}
                          className={`text-xs font-medium px-3 py-1.5 rounded-full border transition-all ${
                            activeTopic === topic
                              ? 'bg-purple-brand text-white border-purple-brand font-semibold shadow-2xs'
                              : 'bg-white text-dark border-border hover:border-purple-brand/50'
                          }`}
                        >
                          {topic}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono text-dark-muted font-semibold mb-1">
                        Your Name
                      </label>
                      <input
                        type="text"
                        name="name"
                        required
                        placeholder="e.g. Rahul Sharma"
                        className="w-full px-4 py-2 rounded-xl border border-border bg-white text-dark text-sm focus:outline-none focus:ring-2 focus:ring-orange-brand"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-mono text-dark-muted font-semibold mb-1">
                        Your Email
                      </label>
                      <input
                        type="email"
                        name="email"
                        required
                        placeholder="e.g. rahul@company.com"
                        className="w-full px-4 py-2 rounded-xl border border-border bg-white text-dark text-sm focus:outline-none focus:ring-2 focus:ring-orange-brand"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono text-dark-muted font-semibold mb-1">
                      Message
                    </label>
                    <textarea
                      name="message"
                      rows={4}
                      required
                      placeholder="Write your message here..."
                      className="w-full px-4 py-2 rounded-xl border border-border bg-white text-dark text-sm focus:outline-none focus:ring-2 focus:ring-orange-brand"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-orange-brand hover:bg-orange-hover text-white font-semibold text-sm shadow-orange-glow transition-all"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send Inquiry Message</span>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ==================== FOOTER ==================== */}
      <footer className="bg-purple-brand text-white py-12 border-t border-purple-dark text-left">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-white text-purple-brand font-heading font-extrabold flex items-center justify-center text-lg">
                M
              </div>
              <div>
                <h4 className="font-heading font-bold text-lg text-white">Meghnath Varande</h4>
                <p className="text-xs text-white/70">
                  AI &amp; Machine Learning Diploma Student &bull; Adarsh Institute of Tech (MSBTE)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <FloatingTooltip content="GitHub Profile">
                <a
                  href="https://github.com/meghnathvarande2-oss"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="w-4 h-4" />
                </a>
              </FloatingTooltip>

              <FloatingTooltip content="LinkedIn Profile">
                <a
                  href="https://www.linkedin.com/in/meghnath-varande-10823b438"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              </FloatingTooltip>

              <FloatingTooltip content="Send Direct Email">
                <a
                  href="mailto:meghnathvarande2@gmail.com"
                  className="p-2.5 rounded-full bg-orange-brand hover:bg-orange-hover text-white transition-colors"
                  aria-label="Email"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </FloatingTooltip>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-white/60 gap-4">
            <p>&copy; {new Date().getFullYear()} Meghnath Varande. All rights reserved.</p>
            <p className="flex items-center gap-1">
              Built with Space Grotesk, Inter, and JetBrains Mono &bull; White + Purple + Orange Theme
            </p>
          </div>
        </div>
      </footer>

      {/* ==================== RESUME MODAL ==================== */}
      {resumeModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        >
          <div className="relative w-full max-w-2xl max-h-[90vh] bg-white rounded-3xl shadow-elevated overflow-y-auto p-6 sm:p-8 text-left border border-border">
            {/* Close Button */}
            <button
              onClick={() => setResumeModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-dark-muted hover:text-orange-brand hover:bg-bg-alt transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Resume Content Container for Printing */}
            <div id="printable-resume" className="space-y-6">
              {/* Resume Header */}
              <div className="border-b border-border pb-4">
                <h2 className="text-2xl font-heading font-extrabold text-purple-brand">
                  MEGHNATH VARANDE
                </h2>
                <p className="text-sm font-semibold text-orange-brand mt-0.5">
                  AI &amp; Machine Learning Diploma Student (MSBTE)
                </p>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-dark-muted mt-2 font-mono">
                  <span>meghnathvarande2@gmail.com</span>
                  <span>&bull;</span>
                  <span>Patan, Maharashtra, India</span>
                  <span>&bull;</span>
                  <span>github.com/meghnathvarande2-oss</span>
                </div>
              </div>

              {/* Career Objective */}
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-purple-brand border-b border-border pb-1 mb-2">
                  Career Objective
                </h3>
                <p className="text-xs sm:text-sm text-dark-muted leading-relaxed">
                  Enthusiastic and disciplined 2nd-year AI &amp; ML diploma student (93% SSC merit)
                  seeking an entry-level internship in AI, data analysis, or Python automation.
                  Dedicated to writing clean, maintainable code, leveraging NumPy and Pandas, and
                  rapidly learning within professional engineering teams.
                </p>
              </div>

              {/* Education */}
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-purple-brand border-b border-border pb-1 mb-2">
                  Education
                </h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs sm:text-sm font-bold text-dark">
                      <span>Diploma in AI &amp; Machine Learning</span>
                      <span className="font-mono text-orange-brand">2024 &ndash; 2028</span>
                    </div>
                    <p className="text-xs text-dark-muted">
                      Adarsh Institute of Technology, Vita (MSBTE) &bull; Current 2nd Year
                    </p>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs sm:text-sm font-bold text-dark">
                      <span>Secondary School Certificate (SSC) &mdash; 93% Distinction</span>
                      <span className="font-mono text-purple-brand">Feb 2025</span>
                    </div>
                    <p className="text-xs text-dark-muted">
                      Maharashtra State Board &bull; Highest Academic Merit in Math &amp; Science
                    </p>
                  </div>
                </div>
              </div>

              {/* Technical Skills */}
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-purple-brand border-b border-border pb-1 mb-2">
                  Technical Skills &amp; Proficiencies
                </h3>
                <div className="text-xs sm:text-sm text-dark-muted space-y-1">
                  <p>
                    <strong className="text-dark">Programming:</strong> Python (Beginner to Intermediate), C (Intermediate), C++ (Intermediate), Java (Intermediate)
                  </p>
                  <p>
                    <strong className="text-dark">Data Science &amp; AI:</strong> NumPy (Intermediate), Pandas (Beginner), ML Fundamentals (Beginner), GenAI Fundamentals (Beginner)
                  </p>
                  <p>
                    <strong className="text-dark">Web &amp; Tools:</strong> HTML (Intermediate), CSS (Beginner), JavaScript (Beginner), Git (Daily Use), GitHub (Daily Use)
                  </p>
                </div>
              </div>

              {/* Featured Projects */}
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-purple-brand border-b border-border pb-1 mb-2">
                  Academic Projects
                </h3>
                <div className="space-y-2 text-xs sm:text-sm">
                  <div>
                    <span className="font-bold text-dark">Student Performance Analyzer</span>{' '}
                    <span className="text-xs font-mono text-orange-brand">(Python, NumPy)</span>
                    <p className="text-dark-muted text-xs">
                      Engineered vectorized data analysis algorithms aggregating grade averages, standard deviations, and class distributions.
                    </p>
                  </div>
                  <div>
                    <span className="font-bold text-dark">ATM Management Simulation</span>{' '}
                    <span className="text-xs font-mono text-purple-brand">(C Language)</span>
                    <p className="text-dark-muted text-xs">
                      Menu-driven banking console software featuring PIN validation and account guard logic.
                    </p>
                  </div>
                </div>
              </div>

              {/* Certifications */}
              <div>
                <h3 className="text-xs font-mono uppercase tracking-wider font-bold text-purple-brand border-b border-border pb-1 mb-2">
                  Certifications
                </h3>
                <ul className="text-xs text-dark-muted list-disc list-inside space-y-0.5">
                  <li>IBM: Foundation in Generative AI</li>
                  <li>Microsoft: Use AI for Everyday Tasks &amp; Effective Prompts</li>
                  <li>Microsoft 365 Copilot Chat (Basic)</li>
                  <li>Coursera / Yuva: AI for All</li>
                  <li>TCS iON: Communication Skills &amp; Interview Prep</li>
                  <li>HP LIFE: Effective Presentations</li>
                </ul>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="mt-6 pt-4 border-t border-border flex items-center justify-between">
              <button
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl border border-border text-xs font-medium text-dark hover:border-purple-brand hover:text-purple-brand transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print / Save PDF</span>
              </button>

              <a
                href="mailto:meghnathvarande2@gmail.com?subject=Internship%20Offer%20for%20Meghnath"
                className="inline-flex items-center gap-1.5 px-5 py-2 rounded-xl bg-orange-brand hover:bg-orange-hover text-white text-xs font-semibold shadow-orange-glow transition-all"
              >
                <Mail className="w-4 h-4" />
                <span>Offer Internship</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
