import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export interface SmartAnimateTextProps {
  value: string;
  className?: string;
  direction?: 'up' | 'down';
  words?: string[];
  interval?: number;
}

/**
 * SmartAnimateText Component
 * Morphing / rolling character text transition with blur, scale, and spring physics.
 * Perfect for hero rotating action words: Building., Learning., Developing., Innovating.
 */
export const SmartAnimateText: React.FC<SmartAnimateTextProps> = ({
  value,
  className = '',
  direction = 'up',
  words,
  interval = 2800,
}) => {
  const [internalValue, setInternalValue] = useState(value);
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mq.matches);
  }, []);

  // If words array is provided, cycle through them automatically
  useEffect(() => {
    if (!words || words.length <= 1) {
      setInternalValue(value);
      return;
    }

    let currentIndex = words.indexOf(value);
    if (currentIndex === -1) currentIndex = 0;

    const timer = setInterval(() => {
      currentIndex = (currentIndex + 1) % words.length;
      setInternalValue(words[currentIndex]);
    }, interval);

    return () => clearInterval(timer);
  }, [words, value, interval]);

  // When value prop updates directly
  useEffect(() => {
    if (!words) {
      setInternalValue(value);
    }
  }, [value, words]);

  const yOffset = direction === 'up' ? 24 : -24;

  if (prefersReducedMotion) {
    return <span className={`inline-block text-orange-brand ${className}`}>{internalValue}</span>;
  }

  return (
    <span className={`relative inline-flex items-center overflow-hidden font-heading ${className}`}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={internalValue}
          initial={{ opacity: 0, y: yOffset, filter: 'blur(4px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -yOffset, filter: 'blur(4px)' }}
          transition={{
            type: 'spring',
            stiffness: 300,
            damping: 24,
            mass: 0.8,
          }}
          className="inline-block text-orange-brand"
        >
          {internalValue}
        </motion.span>
      </AnimatePresence>
    </span>
  );
};

export default SmartAnimateText;
