# Meghnath Varande — AI & Machine Learning Student Portfolio

> **Production-grade portfolio featuring unlumen UI motion components, White + Purple + Orange design system, and verified academic proficiencies.**

---

## 🎨 1. Design System & 60–30–10 Rule

This portfolio strictly adheres to the requested color palette and visual hierarchy:

| Role | Color | Hex Code | Visual Application |
| :--- | :--- | :--- | :--- |
| **60% Dominant** | White | `#FFFFFF` | Primary background, cards, navbar body, clean negative space |
| **30% Branding** | Deep Purple | `#4F0341` | Brand identities, typography headings, borders, tags, footer |
| **10% Highlights** | Orange | `#FF5841` | Primary CTA buttons, interactive glows, active states, pulse indicators |
| **Main Text** | Dark Gray | `#202124` | High-contrast, accessible body readability (WCAG AAA compliant) |
| **Alternating** | Light Tint | `#FFF7F5` | Alternating section backgrounds (About, Skills, Education) |
| **Dividers** | Border Gray | `#E5E7EB` | Subtle outlines, card boundaries, dividers |

### Typography Tokens
- **Headings:** `Space Grotesk` (600–700)
- **Body:** `Inter` (400–500)
- **Code & Tech Tags:** `JetBrains Mono` (400–500)

---

## 🚀 2. Integrated unlumen UI Components

All requested motion components have been integrated with verified import paths, types, and reduced-motion accessibility:

### 1. `DiaTextReveal`
- **Import:** `import { DiaTextReveal } from "@/components/unlumen-ui/dia-text-reveal";`
- **Location:** `src/components/unlumen-ui/dia-text-reveal.tsx`
- **Behavior:** Inspired by the Dia app and The Browser Company, sweeps a rich Deep Purple (`#4F0341`) to Orange (`#FF5841`) gradient across hero headlines and section titles before settling into brand color. Includes viewport intersection tracking and reduced-motion fallbacks.

### 2. `FloatingNavbar`
- **Import:** `import { FloatingNavbar } from "@/components/unlumen-ui/floating-navbar";`
- **Location:** `src/components/unlumen-ui/floating-navbar.tsx`
- **Behavior:** Sticky floating pill navbar with velocity-aware blur, monogram brand logo, navigation links (Home, About, Skills, Projects, Education, Contact), animated "Projects" dropdown panel with subcategories and icons, and an expanding Orange CTA button ("View Projects"). Includes a responsive mobile navigation drawer.

### 3. `FloatingTooltip`
- **Import:** `import { FloatingTooltip } from "@/components/unlumen-ui/floating-tooltip";`
- **Location:** `src/components/unlumen-ui/floating-tooltip.tsx`
- **Behavior:** Spring-animated floating tooltip component attached to social links (GitHub, LinkedIn, Email), project code links, interactive calculator controls, and skill chips. Supports mouse hover, keyboard focus (`onFocus`/`onBlur`), and touch tap.

### 4. `SmartAnimateText`
- **Import:** `import { SmartAnimateText } from "@/components/unlumen-ui/smart-animate-text";`
- **Location:** `src/components/unlumen-ui/smart-animate-text.tsx`
- **Behavior:** Hero action-word morphing component. Smoothly rotates between `“Building.”`, `“Learning.”`, `“Developing.”`, and `“Innovating.”` using blur, scale, and spring physics without layout jitter.

### 5. `HoverImageList`
- **Import:** `import { HoverImageList } from "@/components/unlumen-ui/hover-image-list";`
- **Location:** `src/components/unlumen-ui/hover-image-list.tsx`
- **Behavior:** Interactive featured works showcase where hovering over project rows activates smooth vertical spring tracking and crossfades high-definition visual previews of the projects.

---

## 🛠️ 3. Technical Skills & Levels (No Invented Percentages)

Categorized into modern cards with clear labels and subtle animations:

- **Programming:**
  - Python — `Beginner to Intermediate`
  - C — `Intermediate`
  - C++ — `Intermediate`
  - Java — `Intermediate`
- **Data Science:**
  - NumPy — `Intermediate`
  - Pandas — `Beginner`
- **AI & Machine Learning:**
  - Machine Learning Fundamentals — `Beginner`
  - Generative AI Fundamentals — `Beginner`
- **Web Development:**
  - HTML — `Intermediate`
  - CSS — `Beginner`
  - JavaScript — `Beginner`
- **Developer Tools:**
  - Git — `Daily Use`
  - GitHub — `Daily Use`

---

## ⚡ 4. How to Run & Build

### Development Server:
```bash
npm run dev
```

### Production Build:
```bash
npm run build
```
Build output is saved to the `dist/` directory and can be deployed to Vercel, Netlify, or GitHub Pages.

### Instant Browser Preview:
- **Built React App:** Double-click `dist/index.html` to view the compiled production application.
- **Standalone Vanilla Version:** Double-click `portfolio/index.html` to view the standalone zero-dependency HTML/CSS/JS build.
