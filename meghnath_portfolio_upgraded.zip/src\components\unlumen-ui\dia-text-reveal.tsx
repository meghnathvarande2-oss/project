import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, useAnimation } from 'framer-motion';

export interface DiaTextRevealProps {
  text: string;
  className?: string;
  colors?: string[];
  duration?: number;
  delay?: number;
  repeat?: boolean;
  repeatDelay?: number;
  startOnView?: boolean;
  once?: boolean;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span' | 'div';
}

/**
 * DiaTextReveal Component
 * Inspired by Dia app and The Browser Company styling.
 * Sweeps a rich dynamic color gradient across typography before settling.
 * Fully supports reduced-motion and responsive wrapping.
 */
export const DiaTextReveal: React.FC<DiaTextRevealProps> = ({
  text,
  className = '',
  colors = ['#4F0341', '#FF5841', '#6B0B5A', '#FF7A66', '#4F0341'],
  duration = 2.4,
  delay = 0.2,
  repeat = false,
  repeatDelay = 4,
  startOnView = true,
  once = true,
  as: Component = 'span',
}) => {
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once });
  const controls = useAnimation();
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    setPrefersReducedMotion(mediaQuery.matches);
    const handler = (e: MediaQueryListEvent) => setPrefersReducedMotion(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  useEffect(() => {
    if (prefersReducedMotion) return;

    if (startOnView ? isInView : true) {
      controls.start({
        backgroundPosition: ['100% 50%', '0% 50%'],
        transition: {
          duration,
          delay,
          ease: [0.16, 1, 0.3, 1],
          repeat: repeat ? Infinity : 0,
          repeatDelay,
        },
      });
    }
  }, [isInView, startOnView, controls, duration, delay, repeat, repeatDelay, prefersReducedMotion]);

  const gradientString = `linear-gradient(90deg, ${colors[0]} 0%, ${colors[1]} 30%, ${colors[2]} 50%, ${colors[3]} 70%, ${colors[4]} 100%)`;

  if (prefersReducedMotion) {
    return (
      <Component className={`text-purple-brand ${className}`}>
        {text}
      </Component>
    );
  }

  return (
    <motion.span
      ref={ref}
      className={`inline-block bg-clip-text text-transparent font-heading ${className}`}
      style={{
        backgroundImage: gradientString,
        backgroundSize: '250% 100%',
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
      }}
      animate={controls}
      initial={{ backgroundPosition: '100% 50%' }}
    >
      {text}
    </motion.span>
  );
};

export default DiaTextReveal;
