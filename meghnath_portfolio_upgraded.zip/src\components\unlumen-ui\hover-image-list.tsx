import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ExternalLink, Github, ArrowUpRight } from 'lucide-react';
import { FloatingTooltip } from './floating-tooltip';

export interface HoverImageListItem {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  description: string;
  tags: string[];
  image: string;
  githubUrl?: string;
  demoUrl?: string;
}

export interface HoverImageListProps {
  items: HoverImageListItem[];
  className?: string;
}

/**
 * HoverImageList Component
 * High-performance list of portfolio works where hovering items smoothly
 * activates an adjacent dynamic visual preview card with spring tracking and crossfading.
 */
export const HoverImageList: React.FC<HoverImageListProps> = ({
  items,
  className = '',
}) => {
  const [activeIndex, setActiveIndex] = useState<number>(0);
  const activeItem = items[activeIndex] || items[0];

  return (
    <div className={`w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-center ${className}`}>
      {/* Left Column: Interactive Project Items */}
      <div className="lg:col-span-7 flex flex-col space-y-3">
        {items.map((item, index) => {
          const isActive = activeIndex === index;

          return (
            <motion.div
              key={item.id}
              onMouseEnter={() => setActiveIndex(index)}
              onFocus={() => setActiveIndex(index)}
              tabIndex={0}
              role="button"
              aria-label={`View ${item.title}`}
              aria-expanded={isActive}
              className={`group relative p-5 md:p-6 rounded-2xl border transition-all duration-300 cursor-pointer text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-orange-brand ${
                isActive
                  ? 'bg-white shadow-elevated border-purple-brand/30 translate-x-1.5'
                  : 'bg-white/60 hover:bg-white border-border opacity-75 hover:opacity-100 hover:border-border-dark'
              }`}
            >
              {/* Active Indicator Bar */}
              {isActive && (
                <motion.div
                  layoutId="hover-active-indicator"
                  className="absolute left-0 top-3 bottom-3 w-1.5 rounded-r-full bg-orange-brand"
                  transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                />
              )}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2.5">
                  <span className="text-xs font-mono font-bold text-orange-brand uppercase tracking-wider">
                    0{index + 1}
                  </span>
                  <span className="text-xs px-2.5 py-0.5 rounded-full font-mono font-medium bg-purple-subtle text-purple-brand">
                    {item.category}
                  </span>
                </div>

                {/* Quick Action Links */}
                <div className="flex items-center gap-2">
                  {item.githubUrl && (
                    <FloatingTooltip content="GitHub Repository">
                      <a
                        href={item.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-1.5 rounded-lg text-dark-muted hover:text-purple-brand hover:bg-purple-subtle transition-colors"
                        aria-label={`GitHub source for ${item.title}`}
                      >
                        <Github className="w-4 h-4" />
                      </a>
                    </FloatingTooltip>
                  )}
                  {item.demoUrl && (
                    <FloatingTooltip content="Interactive Demo">
                      <a
                        href={item.demoUrl}
                        onClick={(e) => e.stopPropagation()}
                        className="p-1.5 rounded-lg text-dark-muted hover:text-orange-brand hover:bg-orange-light transition-colors"
                        aria-label={`Demo for ${item.title}`}
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </a>
                    </FloatingTooltip>
                  )}
                </div>
              </div>

              <h4 className="font-heading font-bold text-lg md:text-xl text-purple-brand group-hover:text-purple-dark transition-colors">
                {item.title}
              </h4>
              <p className="text-xs md:text-sm font-medium text-orange-brand mb-2">
                {item.subtitle}
              </p>
              <p className="text-xs md:text-sm text-dark-muted line-clamp-2 leading-relaxed">
                {item.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 mt-3">
                {item.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-bg-alt text-dark border border-border"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Right Column: Dynamic Hover Preview Screen */}
      <div className="lg:col-span-5 relative w-full h-[360px] md:h-[420px] rounded-3xl overflow-hidden shadow-elevated border border-border bg-purple-brand flex flex-col">
        <AnimatePresence mode="popLayout">
          <motion.div
            key={activeItem.id}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.04 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="absolute inset-0 flex flex-col justify-between p-6 text-white"
          >
            {/* Visual Header / Badge */}
            <div className="flex items-center justify-between z-10">
              <span className="text-xs font-mono font-semibold uppercase px-3 py-1 rounded-full bg-black/40 backdrop-blur-md text-orange-brand border border-orange-brand/30">
                {activeItem.category} Preview
              </span>
              <span className="text-xs font-mono text-white/70">
                Meghnath Portfolio
              </span>
            </div>

            {/* Central Graphic Simulation */}
            <div className="my-auto w-full flex items-center justify-center p-4">
              <div className="w-full max-w-xs rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 p-5 shadow-2xl relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-brand/20 rounded-full blur-2xl pointer-events-none" />
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-3 h-3 rounded-full bg-orange-brand animate-ping" />
                  <div className="text-xs font-mono font-bold tracking-wide text-white">
                    {activeItem.title}
                  </div>
                </div>
                <div className="space-y-2 text-xs font-mono text-white/80">
                  <div className="p-2 rounded bg-black/30 text-[11px] border border-white/5 truncate">
                    &gt; tech: {activeItem.tags.join(' | ')}
                  </div>
                  <div className="text-[11px] text-white/70 line-clamp-3">
                    {activeItem.description}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer inside preview panel */}
            <div className="z-10 pt-4 border-t border-white/10 flex items-center justify-between">
              <div>
                <p className="font-heading font-bold text-sm text-white">{activeItem.title}</p>
                <p className="text-[11px] text-orange-brand font-mono">{activeItem.subtitle}</p>
              </div>

              {activeItem.githubUrl && (
                <a
                  href={activeItem.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-brand text-white text-xs font-semibold hover:bg-orange-hover shadow-orange-glow transition-all"
                >
                  <span>Code</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default HoverImageList;
