/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#FFFFFF',
        'bg-alt': '#FFF7F5',
        purple: {
          brand: '#4F0341',
          DEFAULT: '#4F0341',
          dark: '#38022E',
          light: '#6B0B5A',
          subtle: 'rgba(79, 3, 65, 0.08)',
        },
        orange: {
          brand: '#FF5841',
          DEFAULT: '#FF5841',
          hover: '#E54631',
          light: '#FFEAE6',
          subtle: 'rgba(255, 88, 65, 0.1)',
        },
        dark: {
          DEFAULT: '#202124',
          muted: '#5F6368',
          light: '#80868B',
        },
        border: {
          DEFAULT: '#E5E7EB',
          dark: '#D1D5DB',
        },
      },
      fontFamily: {
        heading: ['"Space Grotesk"', 'sans-serif'],
        sans: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        'soft': '0 4px 20px -2px rgba(79, 3, 65, 0.06)',
        'elevated': '0 12px 32px -4px rgba(79, 3, 65, 0.12)',
        'orange-glow': '0 8px 24px -2px rgba(255, 88, 65, 0.35)',
        'purple-glow': '0 8px 24px -2px rgba(79, 3, 65, 0.25)',
      },
    },
  },
  plugins: [],
}
